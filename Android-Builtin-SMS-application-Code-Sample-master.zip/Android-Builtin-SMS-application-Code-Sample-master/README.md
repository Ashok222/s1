Android-Builtin-SMS-application-Code-Sample
===========================================

This example is using the device’s build-in SMS application to send out the SMS message.


You can find complete tutorial on how to use the code repo here : <a href="http://www.theappguruz.com/blog/android-builtin-sms-application">ANDROID – BUILTIN SMS APPLICATION</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/android-app-development/">Android App Development Company in India</a>



